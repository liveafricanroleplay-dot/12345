import { StackActions } from '@react-navigation/native';
import { setDistribution } from '../actions/distributionActions';
import { navigationRef } from '../routers/RootNavigation';
import { DistributionService } from '../services/distribution.service';
import { AppThunk } from '../store/store';
import { compareFileRecursion } from './loaderThunks';

export const fetchDistribution = (): AppThunk => async (dispatch, state) => {
  try {
    const { cache: caches, ...res } = await DistributionService.get();
    // AFRO CITY RP main server configuration. Keep the existing distribution
    // endpoint for game downloads, news, launcher updates, and cache metadata.
    const afroCityServer = {
      id: 1,
      show: true,
      version: '1.0',
      icon: '',
      events: [],
      slot: 1000,
      bonus: false,
      name: 'AFRO CITY RP',
      description: 'Main SA-MP roleplay server',
      address: '142.132.203.47:14585',
      sampVersion: '0.3.7',
    };
    await dispatch(
      setDistribution({ ...res, projectName: 'AFRO CITY RP', servers: [afroCityServer] }),
    );
    if (!state().settings.skip) {
      await dispatch(compareFileRecursion({ caches }));
    }
  } catch (error: any) {
    console.log(error);
    return navigationRef.current?.dispatch(StackActions.replace('Error'));
  }
};
