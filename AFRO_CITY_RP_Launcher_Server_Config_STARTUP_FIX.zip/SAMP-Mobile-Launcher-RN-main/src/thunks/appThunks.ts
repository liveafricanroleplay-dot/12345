import RNGpuInfo from 'react-native-gpu-info';
import { setGPU, setInitial } from '../actions/appActions';
import { AppThunk } from '../store/store';
import { fetchArticles } from './articleThunks';
import { fetchDistribution } from './distributionThunks';
import { fetchDonates } from './donateThunks';
import { appRegisterDeviceForRemoteMessages } from './notificationThunks';
import { fetchPermisions } from './permisionThunks';
import { fetchInitialSettings } from './settingsThunks';

// Startup must not leave the user on the splash/loading screen forever if a
// network or native-module task hangs. This timeout does not cancel the task;
// it simply allows the rest of startup to continue.
const withStartupTimeout = (task: Promise<unknown>, label: string, ms = 10000) =>
  new Promise<void>(resolve => {
    const timer = setTimeout(() => {
      console.warn(`[startup] ${label} timed out; continuing startup`);
      resolve();
    }, ms);
    task
      .then(() => resolve())
      .catch(error => {
        console.warn(`[startup] ${label} failed; continuing startup`, error);
        resolve();
      })
      .finally(() => clearTimeout(timer));
  });


export const fetchInitialApp = (): AppThunk => async dispatch => {
  try {
    try {
      const glRenderer = RNGpuInfo.getGlRenderer();
      dispatch(setGPU(glRenderer));
    } catch (error) {
      console.warn('[startup] GPU info unavailable', error);
    }

    await withStartupTimeout(dispatch(fetchPermisions()), 'permissions');
    await withStartupTimeout(dispatch(fetchInitialSettings()), 'settings');
    await withStartupTimeout(dispatch(fetchDistribution()), 'distribution');
    await withStartupTimeout(dispatch(fetchArticles()), 'news');
    await withStartupTimeout(dispatch(fetchDonates()), 'donations');
    await withStartupTimeout(dispatch(appRegisterDeviceForRemoteMessages()), 'push registration');
  } finally {
    // Always release the initiation screen even if a task rejects or stalls.
    dispatch(setInitial({ initial: true }));
  }
};
